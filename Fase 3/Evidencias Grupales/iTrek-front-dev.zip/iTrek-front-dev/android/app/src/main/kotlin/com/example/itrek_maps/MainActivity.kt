package com.example.itrek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
